module.exports = {
  apps: [
    {
      name: 'daw-backend',
      script: 'dist/main.js',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        DB_HOST: 'localhost',
        DB_PORT: 5432,
        DB_USERNAME: 'postgres',
        DB_PASSWORD: '', //chicos acá va la contraseña que le pusieron a pgAdmin
        DB_NAME: 'agencia_bd',
        DB_LOGGING: 'false',
        SWAGGER_HABILITADO: 'false',
        JWT_SECRET: 'zK9qF2yX#mP7bV4@nR5wT8!jL3cA1$hD',
      },
      time: true,
    },
  ],
};
