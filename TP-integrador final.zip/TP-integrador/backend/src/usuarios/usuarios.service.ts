import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Usuario, EstadoUsuario } from './usuario.entity';
import * as bcrypt from 'bcrypt';
import { CreateUsuarioDto } from './dtos/create-usuario.dto';
import { UpdateUsuarioDto } from './dtos/update-usuario.dto';

@Injectable()
export class UsuariosService {
  constructor(
    @InjectRepository(Usuario)
    private usuariosRepo: Repository<Usuario>,
  ) {}

  obtenerTodos() {
    return this.usuariosRepo.find();
  }

  obtenerPorId(id: number) {
    return this.usuariosRepo.findOneBy({ id: id });
  }

  // Búsqueda de usuario por nombre para validación de autenticación
  obtenerPorNombre(nombre: string) {
    return this.usuariosRepo.findOneBy({ nombre: nombre });
  }

  async crear(datos: CreateUsuarioDto) {
    // Hash de la contraseña antes de persistir
    const salt = await bcrypt.genSalt(10);
    datos.clave = await bcrypt.hash(datos.clave, salt);

    const nuevoUsuario = this.usuariosRepo.create(datos);
    return this.usuariosRepo.save(nuevoUsuario);
  }

  async actualizar(id: number, datos: UpdateUsuarioDto) {
    // Si se actualiza la contraseña, se vuelve a aplicar el hash
    if (datos.clave) {
      const salt = await bcrypt.genSalt(10);
      datos.clave = await bcrypt.hash(datos.clave, salt);
    }
    await this.usuariosRepo.update(id, datos);
    return this.obtenerPorId(id);
  }

  async darDeBaja(id: number) {
    await this.usuariosRepo.update(id, { estado: EstadoUsuario.BAJA });
    return { mensaje: 'Usuario dado de baja correctamente' };
  }
}
