import { IsString, IsNotEmpty, IsOptional, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { EstadoUsuario } from '../usuario.entity';

export class CreateUsuarioDto {
  @ApiProperty({ description: 'Nombre del usuario' })
  @IsString()
  @IsNotEmpty()
  nombre: string;

  @ApiProperty({ description: 'Clave de acceso' })
  @IsString()
  @IsNotEmpty()
  clave: string;

  @ApiProperty({
    description: 'Estado del usuario',
    enum: EstadoUsuario,
    required: false,
  })
  @IsOptional()
  @IsEnum(EstadoUsuario)
  estado?: EstadoUsuario;
}
