import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SeedService } from './seed.service';
import { Usuario } from '../usuarios/usuario.entity';
import { Cliente } from '../clientes/cliente.entity';
import { Proyecto } from '../proyectos/proyecto.entity';
import { Tarea } from '../tareas/tarea.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Usuario, Cliente, Proyecto, Tarea])],
  providers: [SeedService],
})
export class SeedModule {}
