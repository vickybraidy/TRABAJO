import { Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Usuario, EstadoUsuario } from '../usuarios/usuario.entity';
import { Cliente, EstadoCliente } from '../clientes/cliente.entity';
import { Proyecto, EstadoProyecto } from '../proyectos/proyecto.entity';
import { Tarea, EstadoTarea } from '../tareas/tarea.entity';

@Injectable()
export class SeedService implements OnModuleInit {

  constructor(
    @InjectRepository(Usuario) private readonly usuariosRepo: Repository<Usuario>,
    @InjectRepository(Cliente) private readonly clientesRepo: Repository<Cliente>,
    @InjectRepository(Proyecto) private readonly proyectosRepo: Repository<Proyecto>,
    @InjectRepository(Tarea) private readonly tareasRepo: Repository<Tarea>,
  ) {}

  async onModuleInit() {
    // Si ya hay usuarios cargados, el seed ya fue ejecutado — no repetir
    const cantidad = await this.usuariosRepo.count();
    if (cantidad > 0) return;

    const clientes = await this.cargarClientes();
    await this.cargarUsuarios();
    const proyectos = await this.cargarProyectos(clientes);
    await this.cargarTareas(proyectos);
  }

  private async cargarUsuarios() {
    const salt = await bcrypt.genSalt(10);
    const usuarios = [
      { nombre: 'admin', clave: await bcrypt.hash('admin123', salt), estado: EstadoUsuario.ACTIVO },
      { nombre: 'operador', clave: await bcrypt.hash('operador123', salt), estado: EstadoUsuario.ACTIVO },
    ];
    for (const u of usuarios) {
      await this.usuariosRepo.save(this.usuariosRepo.create(u));
    }
  }

  private async cargarClientes(): Promise<Cliente[]> {
    const datos = [
      { nombre: 'Grupo Clarín Digital', estado: EstadoCliente.ACTIVO },
      { nombre: 'Mercado Libre Argentina', estado: EstadoCliente.ACTIVO },
      { nombre: 'Quilmes Experiencias', estado: EstadoCliente.ACTIVO },
      // Cliente dado de baja — caso de prueba para la regla de negocio
      { nombre: 'Telecom Argentina', estado: EstadoCliente.BAJA },
    ];
    const resultado: Cliente[] = [];
    for (const d of datos) {
      resultado.push(await this.clientesRepo.save(this.clientesRepo.create(d)));
    }
    return resultado;
  }

  private async cargarProyectos(clientes: Cliente[]): Promise<Proyecto[]> {
    const [clarin, mercadoLibre, quilmes] = clientes;

    const definiciones: Array<{ nombre: string; estado: EstadoProyecto; idCliente?: number }> = [
      { nombre: 'Campaña digital verano 2027', estado: EstadoProyecto.ACTIVO, idCliente: clarin.id },
      { nombre: 'Rebranding e-commerce', estado: EstadoProyecto.ACTIVO, idCliente: mercadoLibre.id },
      { nombre: 'Activación marca Quilmes Rock', estado: EstadoProyecto.ACTIVO, idCliente: quilmes.id },
      // Proyecto interno — sin cliente asignado
      { nombre: 'Optimización procesos internos', estado: EstadoProyecto.ACTIVO },
      { nombre: 'Campaña Navidad Clarín 2025', estado: EstadoProyecto.FINALIZADO, idCliente: clarin.id },
    ];

    const resultado: Proyecto[] = [];
    for (const d of definiciones) {
      const proyecto = this.proyectosRepo.create(d);
      resultado.push(await this.proyectosRepo.save(proyecto));
    }
    return resultado;
  }

  private async cargarTareas(proyectos: Proyecto[]) {
    const [campanaVerano, rebranding, activacion, procesos, navidad] = proyectos;
    const datos = [
      // Campaña digital verano 2027
      { descripcion: 'Definir calendario de contenidos para redes', estado: EstadoTarea.PENDIENTE, idProyecto: campanaVerano.id },
      { descripcion: 'Diseño de piezas para Instagram y TikTok', estado: EstadoTarea.PENDIENTE, idProyecto: campanaVerano.id },
      { descripcion: 'Brief creativo aprobado por cliente', estado: EstadoTarea.FINALIZADA, idProyecto: campanaVerano.id },
      // Rebranding e-commerce
      { descripcion: 'Análisis de identidad visual actual', estado: EstadoTarea.FINALIZADA, idProyecto: rebranding.id },
      { descripcion: 'Propuesta de nueva paleta y tipografía', estado: EstadoTarea.PENDIENTE, idProyecto: rebranding.id },
      { descripcion: 'Maquetas de landing page actualizada', estado: EstadoTarea.PENDIENTE, idProyecto: rebranding.id },
      // Activación marca Quilmes Rock
      { descripcion: 'Coordinación con producción del evento', estado: EstadoTarea.FINALIZADA, idProyecto: activacion.id },
      { descripcion: 'Cobertura en vivo redes sociales', estado: EstadoTarea.PENDIENTE, idProyecto: activacion.id },
      // Procesos internos
      { descripcion: 'Auditoría de flujos de aprobación', estado: EstadoTarea.PENDIENTE, idProyecto: procesos.id },
      { descripcion: 'Documentar protocolo de entregas', estado: EstadoTarea.PENDIENTE, idProyecto: procesos.id },
      // Campaña Navidad Clarín 2025 — proyecto finalizado
      { descripcion: 'Producción de spots audiovisuales', estado: EstadoTarea.FINALIZADA, idProyecto: navidad.id },
      { descripcion: 'Pauta en redes y portales', estado: EstadoTarea.FINALIZADA, idProyecto: navidad.id },
    ];
    for (const t of datos) {
      await this.tareasRepo.save(this.tareasRepo.create(t));
    }
  }

}
