import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import helmet from 'helmet';
import { Client } from 'pg';
import { AppModule } from './app.module';

// Crea la base de datos si no existe, antes de que TypeORM intente conectarse.
// TypeORM con synchronize:true crea las tablas pero no la base de datos en sí.
async function crearBaseDeDatosIfNotExists() {
  const dbName = process.env.DB_NAME ?? 'agencia_bd';
  // Nos conectamos a la base 'postgres' que siempre existe, para poder crear la nuestra
  const client = new Client({
    host: process.env.DB_HOST ?? 'localhost',
    port: parseInt(process.env.DB_PORT ?? '5432'),
    user: process.env.DB_USERNAME ?? 'postgres',
    password: process.env.DB_PASSWORD,
    database: 'postgres',
  });
  await client.connect();
  const result = await client.query(
    `SELECT 1 FROM pg_database WHERE datname = $1`,
    [dbName],
  );
  if (result.rowCount === 0) {
    // pg no soporta CREATE DATABASE dentro de una transacción,
    // pero al no usar BEGIN/COMMIT podemos ejecutarlo directo
    await client.query(`CREATE DATABASE "${dbName}"`);
    console.log(`Base de datos "${dbName}" creada exitosamente.`);
  }
  await client.end();
}

async function bootstrap() {
  await crearBaseDeDatosIfNotExists();

  const app = await NestFactory.create(AppModule);

  app.use(helmet());

  // Prefijo global: todas las rutas quedan bajo /api/v1/
  app.setGlobalPrefix('api');
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
  });

  app.useGlobalPipes(
    new ValidationPipe({
      // whitelist: elimina propiedades que no están decoradas en el DTO
      // forbidNonWhitelisted: si vienen propiedades extra, lanza error en vez de ignorarlas
      // transform: convierte automáticamente query params string a number, boolean, etc.
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Swagger solo activo en desarrollo (controlado por variable de entorno)
  if (process.env.SWAGGER_HABILITADO === 'true') {
    const config = new DocumentBuilder()
      .setTitle('Impulso PM — API')
      .setDescription('API de gestión de proyectos para agencia de marketing')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api', app, document);
  }

  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
