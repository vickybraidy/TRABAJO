import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ClientesService } from './clientes.service';
import { CreateClienteDto } from './dtos/create-cliente.dto';
import { UpdateClienteDto } from './dtos/update-cliente.dto';
import { FiltroClienteDto } from './dtos/filtro-cliente.dto';
import { AuthGuard } from '../auth/guards/auth.guard';

@ApiTags('clientes')
@ApiBearerAuth()
@UseGuards(AuthGuard)
@Controller('clientes')
export class ClientesController {

  constructor(private readonly clientesService: ClientesService) {}

  @Get()
  listar(@Query() filtro: FiltroClienteDto) {
    return this.clientesService.obtenerTodos(filtro);
  }

  @Get(':id')
  obtenerUno(@Param('id') id: string) {
    return this.clientesService.obtenerPorId(Number(id));
  }

  @Post()
  crear(@Body() dto: CreateClienteDto) {
    return this.clientesService.crear(dto);
  }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() dto: UpdateClienteDto) {
    return this.clientesService.actualizar(Number(id), dto);
  }

  @Delete(':id')
  darDeBaja(@Param('id') id: string) {
    return this.clientesService.darDeBaja(Number(id));
  }

}
