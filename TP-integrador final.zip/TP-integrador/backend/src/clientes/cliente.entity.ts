import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Proyecto } from '../proyectos/proyecto.entity';

export enum EstadoCliente {
  ACTIVO = 'ACTIVO',
  BAJA = 'BAJA',
}

@Entity({ name: 'clientes' })
export class Cliente {

  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  nombre!: string;

  @Column({ type: 'enum', enum: EstadoCliente })
  estado!: EstadoCliente;

  @Column({ nullable: true })
  telefono!: string;

  @Column({ nullable: true })
  correo!: string;

  @OneToMany(() => Proyecto, (proyecto) => proyecto.cliente)
  proyectos!: Proyecto[];

}
