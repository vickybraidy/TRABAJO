import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateClienteDto {

  @ApiProperty({ example: 'BrandForge Agency' })
  @IsString()
  @IsNotEmpty()
  nombre!: string;

}
