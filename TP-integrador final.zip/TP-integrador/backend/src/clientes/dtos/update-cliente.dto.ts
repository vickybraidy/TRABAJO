import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { CreateClienteDto } from './create-cliente.dto';
import { EstadoCliente } from '../cliente.entity';

export class UpdateClienteDto extends PartialType(CreateClienteDto) {

  @ApiProperty({ enum: EstadoCliente, example: EstadoCliente.ACTIVO, required: false })
  @IsEnum(EstadoCliente)
  @IsOptional()
  estado?: EstadoCliente;

}
