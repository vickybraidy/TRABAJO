import { BadRequestException, forwardRef, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cliente, EstadoCliente } from './cliente.entity';
import { CreateClienteDto } from './dtos/create-cliente.dto';
import { UpdateClienteDto } from './dtos/update-cliente.dto';
import { FiltroClienteDto } from './dtos/filtro-cliente.dto';
import { ProyectosService } from '../proyectos/proyectos.service';

@Injectable()
export class ClientesService {

  constructor(
    @InjectRepository(Cliente)
    private readonly clientesRepo: Repository<Cliente>,
    // forwardRef resuelve la dependencia circular entre ClientesService y ProyectosService
    @Inject(forwardRef(() => ProyectosService))
    private readonly proyectosService: ProyectosService,
  ) {}

  async obtenerTodos(filtro: FiltroClienteDto = {}) {
    const qb = this.clientesRepo
      .createQueryBuilder('cliente')
      .orderBy('cliente.id', 'ASC');

    if (filtro.nombre) {
      qb.andWhere('LOWER(cliente.nombre) LIKE LOWER(:nombre)', { nombre: `%${filtro.nombre}%` });
    }
    if (filtro.estado) {
      qb.andWhere('cliente.estado = :estado', { estado: filtro.estado });
    }

    // Si se envían page y limit se devuelve formato paginado
    if (filtro.page && filtro.limit) {
      const total = await qb.getCount();
      const data = await qb
        .skip((filtro.page - 1) * filtro.limit)
        .take(filtro.limit)
        .getMany();
      return { data, total, page: filtro.page, limit: filtro.limit };
    }

    return qb.getMany();
  }

  async obtenerPorId(id: number) {
    const cliente = await this.clientesRepo.findOneBy({ id });
    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }
    return cliente;
  }

  async crear(dto: CreateClienteDto) {
    const cliente = this.clientesRepo.create(dto);
    // El estado inicial siempre es ACTIVO — no lo decide quien crea el registro
    cliente.estado = EstadoCliente.ACTIVO;
    await this.clientesRepo.save(cliente);
    return { id: cliente.id };
  }

  async actualizar(id: number, dto: UpdateClienteDto) {
    const cliente = await this.clientesRepo.findOneBy({ id });
    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Si se intenta dar de baja, verificar que no tenga proyectos asociados
    if (dto.estado === EstadoCliente.BAJA) {
      const tieneProyectos = await this.proyectosService.existeProyectoPorCliente(id);
      if (tieneProyectos) {
        throw new BadRequestException('No se puede dar de baja un cliente con proyectos asociados');
      }
    }

    this.clientesRepo.merge(cliente, dto);
    return this.clientesRepo.save(cliente);
  }

  async darDeBaja(id: number) {
    const cliente = await this.clientesRepo.findOneBy({ id });
    if (!cliente) {
      throw new NotFoundException('Cliente no encontrado');
    }

    // Un cliente con proyectos activos o finalizados no puede darse de baja
    // porque quedarían proyectos con un cliente inválido
    const tieneProyectos = await this.proyectosService.existeProyectoPorCliente(id);
    if (tieneProyectos) {
      throw new BadRequestException('No se puede dar de baja un cliente con proyectos asociados');
    }

    await this.clientesRepo.update(id, { estado: EstadoCliente.BAJA });
    return { mensaje: 'Cliente dado de baja correctamente' };
  }

  // Método usado por ProyectosService para validar que el cliente exista y esté activo
  async existeClienteActivo(id: number): Promise<boolean> {
    return this.clientesRepo.exists({ where: { id, estado: EstadoCliente.ACTIVO } });
  }

}
