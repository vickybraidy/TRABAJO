import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateTareaDto {

  @ApiProperty({ example: 'Definir calendario de publicaciones' })
  @IsString()
  @IsNotEmpty()
  descripcion!: string;

}
