import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { CreateTareaDto } from './create-tarea.dto';
import { EstadoTarea } from '../tarea.entity';

export class UpdateTareaDto extends PartialType(CreateTareaDto) {

  @ApiProperty({ enum: EstadoTarea, example: EstadoTarea.PENDIENTE, required: false })
  @IsEnum(EstadoTarea)
  @IsOptional()
  estado?: EstadoTarea;

}
