import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Proyecto } from '../proyectos/proyecto.entity';

export enum EstadoTarea {
  PENDIENTE = 'PENDIENTE',
  FINALIZADA = 'FINALIZADA',
  BAJA = 'BAJA',
}

@Entity({ name: 'tareas' })
export class Tarea {

  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  descripcion!: string;

  @Column({ type: 'enum', enum: EstadoTarea })
  estado!: EstadoTarea;

  // FK del proyecto al que pertenece la tarea
  @Column({ name: 'id_proyecto' })
  idProyecto!: number;

  @ManyToOne(() => Proyecto, (proyecto) => proyecto.tareas)
  @JoinColumn({ name: 'id_proyecto' })
  proyecto!: Proyecto;

}
