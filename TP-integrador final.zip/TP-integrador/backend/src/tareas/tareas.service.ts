import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tarea, EstadoTarea } from './tarea.entity';
import { CreateTareaDto } from './dtos/create-tarea.dto';
import { UpdateTareaDto } from './dtos/update-tarea.dto';

@Injectable()
export class TareasService {

  constructor(
    @InjectRepository(Tarea)
    private readonly tareasRepo: Repository<Tarea>,
  ) {}

  obtenerPorProyecto(idProyecto: number) {
    // Ordenamos por id para que las tareas aparezcan en orden de creación
    return this.tareasRepo.find({ where: { idProyecto }, order: { id: 'ASC' } });
  }

  async crear(dto: CreateTareaDto, idProyecto: number) {
    const tarea = this.tareasRepo.create(dto);
    // El estado inicial siempre es PENDIENTE — no viene en el DTO para no permitir que
    // el frontend cree una tarea ya finalizada desde el formulario
    tarea.estado = EstadoTarea.PENDIENTE;
    // El idProyecto viene de la ruta /:id/tareas, no del body del request
    tarea.idProyecto = idProyecto;
    await this.tareasRepo.save(tarea);
    return { id: tarea.id };
  }

  async actualizar(id: number, dto: UpdateTareaDto) {
    const tarea = await this.tareasRepo.findOneBy({ id });
    if (!tarea) {
      throw new NotFoundException('Tarea no encontrada');
    }
    this.tareasRepo.merge(tarea, dto);
    return this.tareasRepo.save(tarea);
  }

  async darDeBaja(id: number) {
    const tarea = await this.tareasRepo.findOneBy({ id });
    if (!tarea) {
      throw new NotFoundException('Tarea no encontrada');
    }
    await this.tareasRepo.update(id, { estado: EstadoTarea.BAJA });
    return { mensaje: 'Tarea dada de baja correctamente' };
  }

}
