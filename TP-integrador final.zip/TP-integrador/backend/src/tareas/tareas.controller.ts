import { Controller, Get, Post, Patch, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { TareasService } from './tareas.service';
import { CreateTareaDto } from './dtos/create-tarea.dto';
import { UpdateTareaDto } from './dtos/update-tarea.dto';
import { AuthGuard } from '../auth/guards/auth.guard';

@ApiTags('tareas')
@ApiBearerAuth()
@UseGuards(AuthGuard)
@Controller('proyectos/:idProyecto/tareas')
export class TareasController {

  constructor(private readonly tareasService: TareasService) {}

  @Get()
  listar(@Param('idProyecto') idProyecto: string) {
    return this.tareasService.obtenerPorProyecto(Number(idProyecto));
  }

  @Post()
  crear(@Param('idProyecto') idProyecto: string, @Body() dto: CreateTareaDto) {
    return this.tareasService.crear(dto, Number(idProyecto));
  }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() dto: UpdateTareaDto) {
    return this.tareasService.actualizar(Number(id), dto);
  }

  @Delete(':id')
  darDeBaja(@Param('id') id: string) {
    return this.tareasService.darDeBaja(Number(id));
  }

}
