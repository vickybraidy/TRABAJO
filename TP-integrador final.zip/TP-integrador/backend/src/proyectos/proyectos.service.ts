import { BadRequestException, forwardRef, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Proyecto, EstadoProyecto } from './proyecto.entity';
import { CreateProyectoDto } from './dtos/create-proyecto.dto';
import { UpdateProyectoDto } from './dtos/update-proyecto.dto';
import { FiltroProyectoDto } from './dtos/filtro-proyecto.dto';
import { ClientesService } from '../clientes/clientes.service';

@Injectable()
export class ProyectosService {

  constructor(
    @InjectRepository(Proyecto)
    private readonly proyectosRepo: Repository<Proyecto>,
    // forwardRef resuelve la dependencia circular entre ProyectosService y ClientesService
    @Inject(forwardRef(() => ClientesService))
    private readonly clientesService: ClientesService,
  ) {}

  async obtenerTodos(filtro: FiltroProyectoDto = {}) {
    // Usamos QueryBuilder en vez de find() porque necesitamos agregar WHERE dinámicos
    // según qué filtros lleguen — con find() no se pueden hacer condiciones opcionales fácilmente
    const qb = this.proyectosRepo
      .createQueryBuilder('proyecto')
      // leftJoinAndSelect trae el cliente en la misma query, sin N+1
      .leftJoinAndSelect('proyecto.cliente', 'cliente')
      .orderBy(`proyecto.${filtro.orderBy || 'id'}`, filtro.order || 'ASC');

    if (filtro.nombre) {
      // LOWER en ambos lados para búsqueda sin distinción de mayúsculas
      qb.andWhere('LOWER(proyecto.nombre) LIKE LOWER(:nombre)', { nombre: `%${filtro.nombre}%` });
    }
    if (filtro.estado) {
      qb.andWhere('proyecto.estado = :estado', { estado: filtro.estado });
    }

    // Si se envían page y limit se devuelve formato paginado con total para el frontend
    if (filtro.page && filtro.limit) {
      const total = await qb.getCount();
      const data = await qb
        .skip((filtro.page - 1) * filtro.limit)
        .take(filtro.limit)
        .getMany();
      return { data, total, page: filtro.page, limit: filtro.limit };
    }

    return qb.getMany();
  }

  async obtenerPorId(id: number) {
    const proyecto = await this.proyectosRepo.findOne({
      where: { id },
      relations: { cliente: true, tareas: true },
      order: { tareas: { id: 'ASC' } },
    });
    if (!proyecto) {
      throw new NotFoundException('Proyecto no encontrado');
    }
    return proyecto;
  }

  async crear(dto: CreateProyectoDto) {
    // Si se envía un cliente, debe estar activo — no se puede asignar uno dado de baja
    if (dto.idCliente) {
      const clienteActivo = await this.clientesService.existeClienteActivo(dto.idCliente);
      if (!clienteActivo) {
        throw new BadRequestException('El cliente especificado no existe o está inactivo');
      }
    }

    const proyecto = this.proyectosRepo.create(dto);
    proyecto.estado = EstadoProyecto.ACTIVO;
    await this.proyectosRepo.save(proyecto);
    return { id: proyecto.id };
  }

  async actualizar(id: number, dto: UpdateProyectoDto) {
    const proyecto = await this.proyectosRepo.findOneBy({ id });
    if (!proyecto) {
      throw new NotFoundException('Proyecto no encontrado');
    }

    if (dto.idCliente) {
      const clienteActivo = await this.clientesService.existeClienteActivo(dto.idCliente);
      if (!clienteActivo) {
        throw new BadRequestException('El cliente especificado no existe o está inactivo');
      }
    }

    this.proyectosRepo.merge(proyecto, dto);
    return this.proyectosRepo.save(proyecto);
  }

  async darDeBaja(id: number) {
    const proyecto = await this.proyectosRepo.findOneBy({ id });
    if (!proyecto) {
      throw new NotFoundException('Proyecto no encontrado');
    }
    await this.proyectosRepo.update(id, { estado: EstadoProyecto.BAJA });
    return { mensaje: 'Proyecto dado de baja correctamente' };
  }

  // ClientesService llama a este método antes de dar de baja un cliente.
  // Solo bloqueamos si hay proyectos ACTIVOS o FINALIZADOS — los proyectos ya dados de baja
  // no son un problema porque ya no están operativos
  async existeProyectoPorCliente(idCliente: number): Promise<boolean> {
    return this.proyectosRepo.exists({
      where: {
        cliente: { id: idCliente },
        estado: In([EstadoProyecto.ACTIVO, EstadoProyecto.FINALIZADO]),
      },
    });
  }

}
