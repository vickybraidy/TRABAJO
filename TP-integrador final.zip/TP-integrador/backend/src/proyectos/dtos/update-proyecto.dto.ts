import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { CreateProyectoDto } from './create-proyecto.dto';
import { EstadoProyecto } from '../proyecto.entity';

export class UpdateProyectoDto extends PartialType(CreateProyectoDto) {

  @ApiProperty({ enum: EstadoProyecto, example: EstadoProyecto.ACTIVO, required: false })
  @IsEnum(EstadoProyecto)
  @IsOptional()
  estado?: EstadoProyecto;

}
