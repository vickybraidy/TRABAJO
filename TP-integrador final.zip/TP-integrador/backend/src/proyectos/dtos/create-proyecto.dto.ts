import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateProyectoDto {

  @ApiProperty({ example: 'Campaña redes Q3 2026' })
  @IsString()
  @IsNotEmpty()
  nombre!: string;

  @ApiProperty({ example: 1, required: false, description: 'ID del cliente. Omitir para proyectos internos.' })
  @IsNumber()
  @IsOptional()
  idCliente?: number;

}
