import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum, IsIn, IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { EstadoProyecto } from '../proyecto.entity';

export class FiltroProyectoDto {

  @ApiProperty({ required: false, description: 'Filtra por nombre (búsqueda parcial)' })
  @IsOptional()
  @IsString()
  nombre?: string;

  @ApiProperty({ required: false, enum: EstadoProyecto })
  @IsOptional()
  @IsEnum(EstadoProyecto)
  estado?: EstadoProyecto;

  @ApiProperty({ required: false, default: 1, minimum: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @ApiProperty({ required: false, default: 10, minimum: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number;

  @ApiProperty({ required: false, enum: ['nombre', 'estado', 'id'], default: 'id' })
  @IsOptional()
  @IsString()
  @IsIn(['nombre', 'estado', 'id'])
  orderBy?: string;

  @ApiProperty({ required: false, enum: ['ASC', 'DESC'], default: 'ASC' })
  @IsOptional()
  @IsIn(['ASC', 'DESC'])
  order?: 'ASC' | 'DESC';

}
