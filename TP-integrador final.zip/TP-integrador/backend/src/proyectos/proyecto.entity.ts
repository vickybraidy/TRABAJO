import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { Cliente } from '../clientes/cliente.entity';
import { Tarea } from '../tareas/tarea.entity';

export enum EstadoProyecto {
  ACTIVO = 'ACTIVO',
  FINALIZADO = 'FINALIZADO',
  BAJA = 'BAJA',
}

@Entity({ name: 'proyectos' })
export class Proyecto {

  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  nombre!: string;

  @Column({ type: 'enum', enum: EstadoProyecto })
  estado!: EstadoProyecto;

  // FK del cliente — nullable porque los proyectos internos no tienen cliente
  @Column({ name: 'id_cliente', nullable: true })
  idCliente!: number;

  @ManyToOne(() => Cliente, (cliente) => cliente.proyectos, { nullable: true })
  @JoinColumn({ name: 'id_cliente' })
  cliente!: Cliente;

  @OneToMany(() => Tarea, (tarea) => tarea.proyecto)
  tareas!: Tarea[];

}
