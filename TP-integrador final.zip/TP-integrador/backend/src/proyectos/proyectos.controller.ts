import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ProyectosService } from './proyectos.service';
import { CreateProyectoDto } from './dtos/create-proyecto.dto';
import { UpdateProyectoDto } from './dtos/update-proyecto.dto';
import { FiltroProyectoDto } from './dtos/filtro-proyecto.dto';
import { AuthGuard } from '../auth/guards/auth.guard';

@ApiTags('proyectos')
@ApiBearerAuth()
@UseGuards(AuthGuard)
@Controller('proyectos')
export class ProyectosController {

  constructor(private readonly proyectosService: ProyectosService) {}

  @Get()
  listar(@Query() filtro: FiltroProyectoDto) {
    return this.proyectosService.obtenerTodos(filtro);
  }

  @Get(':id')
  obtenerUno(@Param('id') id: string) {
    return this.proyectosService.obtenerPorId(Number(id));
  }

  @Post()
  crear(@Body() dto: CreateProyectoDto) {
    return this.proyectosService.crear(dto);
  }

  @Patch(':id')
  actualizar(@Param('id') id: string, @Body() dto: UpdateProyectoDto) {
    return this.proyectosService.actualizar(Number(id), dto);
  }

  @Delete(':id')
  darDeBaja(@Param('id') id: string) {
    return this.proyectosService.darDeBaja(Number(id));
  }

}
