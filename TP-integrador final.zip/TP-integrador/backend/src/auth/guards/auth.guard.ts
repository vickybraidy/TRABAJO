import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private jwtService: JwtService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = this.extraerTokenDelHeader(request);

    if (!token) {
      throw new UnauthorizedException('Token de acceso requerido');
    }

    try {
      const payload = await this.jwtService.verifyAsync(token);
      // Guardamos el payload en el request para que los controllers puedan leer
      // los datos del usuario sin volver a consultar la base de datos
      request['usuario'] = payload;
    } catch {
      // Llegamos acá si el token está mal firmado, fue modificado o ya expiró
      throw new UnauthorizedException('Token inválido o expirado');
    }

    return true;
  }

  // Solo aceptamos el formato "Bearer <token>" — otros esquemas se rechazan silenciosamente
  private extraerTokenDelHeader(request: Request): string | undefined {
    const [tipo, token] = request.headers['authorization']?.split(' ') ?? [];
    return tipo === 'Bearer' ? token : undefined;
  }

}
