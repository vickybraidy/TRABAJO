import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { LoginDto } from './dtos/login.dto';
import { Usuario, EstadoUsuario } from '../usuarios/usuario.entity';

@Injectable()
export class AuthService {

  constructor(
    @InjectRepository(Usuario)
    private readonly usuariosRepo: Repository<Usuario>,
    private readonly jwtService: JwtService,
  ) {}

  async login(dto: LoginDto): Promise<{ accessToken: string }> {
    // Buscamos usuario activo en una sola consulta — si el usuario no existe o está dado de baja,
    // ambos casos devuelven el mismo mensaje de error (no revelamos si el usuario existe o no)
    const usuario = await this.usuariosRepo.findOneBy({
      nombre: dto.nombre,
      estado: EstadoUsuario.ACTIVO,
    });

    if (!usuario) {
      throw new UnauthorizedException('Usuario no encontrado o inactivo');
    }

    // compareSync es sincrónico pero acá está bien: bcrypt es lento por diseño y
    // el endpoint de login no es de alta concurrencia
    if (!bcrypt.compareSync(dto.clave, usuario.clave)) {
      throw new UnauthorizedException('Credenciales incorrectas');
    }

    // El campo "sub" es la convención JWT para identificar al sujeto del token
    const payload = { nombre: usuario.nombre, sub: usuario.id };
    return { accessToken: this.jwtService.sign(payload) };
  }

}
