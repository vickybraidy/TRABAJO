import { HttpEvent, HttpHandlerFn, HttpRequest } from "@angular/common/http";
import { inject } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { AuthStore } from "./auth-store";

// Interceptor funcional (Angular 21): se registra en provideHttpClient(withInterceptors([...]))
// en vez de heredar de HttpInterceptor — más simple, no necesita clase ni módulo
export function authInterceptor(
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> {

  const authToken = inject(AuthStore).obtenerToken();

  // Si no hay token (usuario no logueado), dejamos pasar la request sin modificar
  // — esto permite que el endpoint de login funcione sin token
  if (!authToken) {
    return next(req);
  }

  // Los HttpRequest son inmutables, hay que clonarlos para modificar los headers
  const reqWithToken = req.clone({
    headers: req.headers.set('Authorization', `Bearer ${authToken}`)
  });

  return next(reqWithToken);
}
