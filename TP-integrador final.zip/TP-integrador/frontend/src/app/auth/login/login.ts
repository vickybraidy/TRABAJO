import { Component, inject } from "@angular/core";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ButtonModule } from "primeng/button";
import { InputTextModule } from "primeng/inputtext";
import { MessageService } from "primeng/api";
import { LoginApiClient } from "./login-api-clientes";
import { AuthStore } from "../auth-store";

@Component({
  selector: "app-login",
  templateUrl: "./login.html",
  styleUrl: "./login.css",
  imports: [ButtonModule, InputTextModule, ReactiveFormsModule]
})
export class Login {

  private readonly loginApiClient: LoginApiClient = inject(LoginApiClient);
  private readonly messageService: MessageService = inject(MessageService);
  private readonly authStore: AuthStore = inject(AuthStore);
  private readonly router: Router = inject(Router);

  readonly form: FormGroup = new FormGroup({
    nombre: new FormControl("", [Validators.required]),
    clave: new FormControl("", [Validators.required])
  });

  iniciarSesion() {
    if (!this.form.valid) {
      this.messageService.add({ severity: "error", summary: "Error", detail: "Los campos son requeridos" });
      return;
    }

    const nombre: string = this.form.value.nombre;
    const clave: string = this.form.value.clave;

    this.loginApiClient.iniciarSesion(nombre, clave).subscribe({
      next: (data) => {
        this.authStore.guardarToken(data.accessToken);
        this.router.navigateByUrl("/proyectos");
      },
      error: () => {
        this.messageService.add({ severity: "error", summary: "Error", detail: "Usuario o contraseña incorrectos" });
      }
    });
  }

}
