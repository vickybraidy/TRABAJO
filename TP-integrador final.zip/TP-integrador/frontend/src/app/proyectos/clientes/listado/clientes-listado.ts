import { Component, effect, inject, model, ModelSignal, OnInit, signal, WritableSignal } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { MessageService } from "primeng/api";
import { TableModule } from "primeng/table";
import { ButtonModule } from "primeng/button";
import { InputTextModule } from "primeng/inputtext";
import { SelectModule } from "primeng/select";
import { DialogModule } from "primeng/dialog";
import { ClientesListadoApiClient } from "./clientes-listado-api-client";
import { GestionCliente } from "../gestion/gestion-cliente";
import { ListClienteDTO } from "./list-cliente-dto";
import { EstadosClientesEnum } from "../estados-clientes-enum";

@Component({
  selector: "app-clientes-listado",
  templateUrl: "./clientes-listado.html",
  styleUrls: ["./clientes-listado.css"],
  imports: [TableModule, ButtonModule, InputTextModule, SelectModule, FormsModule, DialogModule, GestionCliente]
})
export class ClientesListado implements OnInit {

  private readonly messageService: MessageService = inject(MessageService);
  private readonly clientesListadoApiClient: ClientesListadoApiClient = inject(ClientesListadoApiClient);

  visible: ModelSignal<boolean> = model(false);
  clientes: WritableSignal<ListClienteDTO[]> = signal([]);
  dialogVisible: WritableSignal<boolean> = signal(false);
  clienteSeleccionado: WritableSignal<ListClienteDTO | null> = signal<ListClienteDTO | null>(null);

  // Filtros de búsqueda avanzada
  filtroNombre: string = '';
  filtroEstado: string = '';
  readonly opcionesEstado = Object.values(EstadosClientesEnum);

  constructor() {
    effect(() => {
      if (!this.dialogVisible()) {
        this.refrescarClientes();
      }
    });
  }

  ngOnInit(): void {
    this.refrescarClientes();
  }

  refrescarClientes(): void {
    const estado = this.filtroEstado as EstadosClientesEnum | undefined;
    const nombre = this.filtroNombre.trim() || undefined;
    this.clientesListadoApiClient.buscarClientes(estado, nombre).subscribe({
      next: (data) => this.clientes.set(data),
      error: () => this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron obtener los clientes' })
    });
  }

  buscar(): void {
    this.refrescarClientes();
  }

  limpiarFiltros(): void {
    this.filtroNombre = '';
    this.filtroEstado = '';
    this.refrescarClientes();
  }

  crearCliente(): void {
    this.clienteSeleccionado.set(null);
    this.dialogVisible.set(true);
  }

  editarCliente(cliente: ListClienteDTO): void {
    this.clienteSeleccionado.set(cliente);
    this.dialogVisible.set(true);
  }

}
