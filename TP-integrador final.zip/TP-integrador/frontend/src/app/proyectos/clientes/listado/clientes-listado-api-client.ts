import { inject, Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { ListClienteDTO } from "./list-cliente-dto";
import { EstadosClientesEnum } from "../estados-clientes-enum";

@Injectable({ providedIn: 'root' })
export class ClientesListadoApiClient {

  private readonly httpClient = inject(HttpClient);

  buscarClientes(estado?: EstadosClientesEnum, nombre?: string): Observable<ListClienteDTO[]> {
    let params = new HttpParams();
    if (estado) params = params.set('estado', estado);
    if (nombre) params = params.set('nombre', nombre);
    return this.httpClient.get<ListClienteDTO[]>('/api/v1/clientes', { params });
  }

}
