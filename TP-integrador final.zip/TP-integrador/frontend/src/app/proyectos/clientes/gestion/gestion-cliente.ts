import { Component, computed, effect, inject, model, ModelSignal, Signal, signal, WritableSignal } from "@angular/core";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { MessageService } from "primeng/api";
import { DialogModule } from "primeng/dialog";
import { InputTextModule } from "primeng/inputtext";
import { SelectModule } from "primeng/select";
import { ButtonModule } from "primeng/button";
import { GestionClienteApiClient } from "./gestion-cliente-api-client";
import { ListClienteDTO } from "../listado/list-cliente-dto";
import { CreateClienteDTO } from "./create-cliente-dto";
import { UpdateClienteDto } from "./update-cliente-dto";
import { EstadosClientesEnum } from "../estados-clientes-enum";

@Component({
  selector: "app-gestion-cliente",
  templateUrl: "./gestion-cliente.html",
  styleUrls: ["./gestion-cliente.css"],
  imports: [DialogModule, InputTextModule, SelectModule, ButtonModule, ReactiveFormsModule]
})
export class GestionCliente {

  visible: ModelSignal<boolean> = model(false);
  clienteSeleccionado: ModelSignal<ListClienteDTO | null> = model<ListClienteDTO | null>(null);

  readonly estados: WritableSignal<string[]> = signal(Object.values(EstadosClientesEnum));

  private readonly messageService: MessageService = inject(MessageService);
  private readonly gestionClienteApiClient = inject(GestionClienteApiClient);

  header: Signal<string> = computed(() =>
    this.clienteSeleccionado() ? "Editar cliente" : "Crear cliente"
  );

  readonly form: FormGroup = new FormGroup({
    nombre: new FormControl("", [Validators.required]),
    estado: new FormControl(null)
  });

  constructor() {
    effect(() => {
      const c = this.clienteSeleccionado();
      if (c) {
        this.form.patchValue({ nombre: c.nombre, estado: c.estado });
      } else {
        this.form.reset({ nombre: "", estado: null });
      }
    });
  }

  cerrarDialog(): void {
    this.clienteSeleccionado.set(null);
    this.form.reset({ nombre: "", estado: null });
    this.visible.set(false);
  }

  guardarCliente(): void {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Complete todos los campos requeridos' });
      return;
    }

    const formRawValue = this.form.getRawValue();

    if (this.clienteSeleccionado()) {
      const dto: UpdateClienteDto = { nombre: formRawValue.nombre, estado: formRawValue.estado };
      this.gestionClienteApiClient.actualizarCliente(this.clienteSeleccionado()!.id, dto).subscribe({
        next: () => {
          this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Cliente actualizado correctamente' });
          this.cerrarDialog();
        },
        error: (err) => {
          const detail = err.error?.statusCode >= 400 && err.error?.statusCode < 500
            ? err.error.message
            : "Error al actualizar el cliente";
          this.messageService.add({ severity: 'error', summary: 'Error', detail });
        }
      });
    } else {
      const dto: CreateClienteDTO = { nombre: formRawValue.nombre };
      this.gestionClienteApiClient.crearCliente(dto).subscribe({
        next: () => {
          this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Cliente creado correctamente' });
          this.cerrarDialog();
        },
        error: (err) => {
          const detail = err.error?.statusCode >= 400 && err.error?.statusCode < 500
            ? err.error.message
            : "Error al crear el cliente";
          this.messageService.add({ severity: 'error', summary: 'Error', detail });
        }
      });
    }
  }

}
