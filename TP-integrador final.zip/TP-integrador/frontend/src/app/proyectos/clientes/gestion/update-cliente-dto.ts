import { EstadosClientesEnum } from "../estados-clientes-enum";

export interface UpdateClienteDto {
  nombre: string;
  estado: EstadosClientesEnum;
}
