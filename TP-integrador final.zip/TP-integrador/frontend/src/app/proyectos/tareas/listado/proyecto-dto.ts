import { EstadosProyectosEnum } from "../../estados-proyectos-enum";
import { ListClienteDTO } from "../../clientes/listado/list-cliente-dto";
import { ListTareaDTO } from "./list-tarea-dto";

export interface ProyectoDTO {
  id: number;
  nombre: string;
  cliente: ListClienteDTO | null;
  estado: EstadosProyectosEnum;
  tareas: ListTareaDTO[];
}
