import { Component, computed, effect, inject, OnInit, Signal, signal, WritableSignal } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { MessageService } from "primeng/api";
import { TableModule } from "primeng/table";
import { ButtonModule } from "primeng/button";
import { TooltipModule } from "primeng/tooltip";
import { Template } from "../../../template/template";
import { GestionTarea } from "../gestion/gestion-tarea";
import { ProyectoApiClient } from "./proyecto-api-client";
import { ProyectoDTO } from "./proyecto-dto";
import { ListTareaDTO } from "./list-tarea-dto";

@Component({
  selector: "app-tareas-listado",
  templateUrl: "./tareas-listado.html",
  styleUrls: ["./tareas-listado.css"],
  imports: [TableModule, ButtonModule, Template, TooltipModule, GestionTarea]
})
export class TareasListado implements OnInit {

  private readonly messageService: MessageService = inject(MessageService);
  private readonly proyectoApiClient: ProyectoApiClient = inject(ProyectoApiClient);
  private readonly router: Router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  proyecto: WritableSignal<ProyectoDTO | null> = signal(null);
  tareas: Signal<ListTareaDTO[]> = computed(() => this.proyecto()?.tareas || []);
  dialogVisible: WritableSignal<boolean> = signal(false);
  tareaSeleccionada: WritableSignal<ListTareaDTO | null> = signal<ListTareaDTO | null>(null);
  readonly idProyecto: WritableSignal<number | null> = signal<number | null>(null);

  constructor() {
    // Leemos el id del proyecto desde la URL (/proyectos/:id/tareas)
    this.idProyecto.set(Number(this.route.snapshot.paramMap.get('id')));

    // Si la URL no tiene un id válido, volvemos a la lista antes de cargar nada
    if (!this.idProyecto()) {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Id de proyecto no válido' });
      this.router.navigateByUrl("/proyectos");
    }

    // Cuando se cierra el dialog de tarea, recargamos el proyecto completo (con tareas actualizadas)
    effect(() => {
      if (!this.dialogVisible()) {
        this.refreshProyecto();
      }
    });
  }

  ngOnInit(): void {
    this.refreshProyecto();
  }

  refreshProyecto(): void {
    this.proyectoApiClient.buscarProyecto(this.idProyecto()).subscribe({
      next: (data) => this.proyecto.set(data),
      error: () => this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo obtener el proyecto' })
    });
  }

  crearTarea(): void {
    this.tareaSeleccionada.set(null);
    this.dialogVisible.set(true);
  }

  editarTarea(tarea: ListTareaDTO): void {
    this.tareaSeleccionada.set(tarea);
    this.dialogVisible.set(true);
  }

  volver(): void {
    this.router.navigateByUrl("/proyectos");
  }

}
