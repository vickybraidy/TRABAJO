import { inject, Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { ListProyectoDTO } from "./list-proyecto-dto";

@Injectable({ providedIn: 'root' })
export class ProyectosListadoApiClient {

  private readonly httpClient = inject(HttpClient);

  buscarProyectos(filtro?: { nombre?: string; estado?: string }): Observable<ListProyectoDTO[]> {
    let params = new HttpParams();
    if (filtro?.nombre) params = params.set('nombre', filtro.nombre);
    if (filtro?.estado) params = params.set('estado', filtro.estado);
    return this.httpClient.get<ListProyectoDTO[]>('/api/v1/proyectos', { params });
  }

}
