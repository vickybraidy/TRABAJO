import { Component, effect, inject, OnInit, signal, WritableSignal } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { MessageService } from "primeng/api";
import { TableModule } from "primeng/table";
import { ButtonModule } from "primeng/button";
import { InputTextModule } from "primeng/inputtext";
import { SelectModule } from "primeng/select";
import { TooltipModule } from "primeng/tooltip";
import { Router } from "@angular/router";
import { Template } from "../../template/template";
import { GestionProyecto } from "../gestion/gestion-proyecto";
import { ProyectosListadoApiClient } from "./proyectos-listado-api-client";
import { ListProyectoDTO } from "./list-proyecto-dto";
import { EstadosProyectosEnum } from "../estados-proyectos-enum";

@Component({
  selector: "app-proyectos-listado",
  templateUrl: "./proyectos-listado.html",
  styleUrls: ["./proyectos-listado.css"],
  imports: [TableModule, ButtonModule, InputTextModule, SelectModule, FormsModule, Template, TooltipModule, GestionProyecto]
})
export class ProyectosListado implements OnInit {

  private readonly messageService: MessageService = inject(MessageService);
  private readonly proyectosListadoApiClient: ProyectosListadoApiClient = inject(ProyectosListadoApiClient);
  private readonly router: Router = inject(Router);

  proyectos: WritableSignal<ListProyectoDTO[]> = signal([]);
  dialogVisible: WritableSignal<boolean> = signal(false);
  proyectoSeleccionado: WritableSignal<ListProyectoDTO | null> = signal<ListProyectoDTO | null>(null);

  // Filtros de búsqueda avanzada
  filtroNombre: string = '';
  filtroEstado: string = '';
  readonly opcionesEstado = Object.values(EstadosProyectosEnum);

  constructor() {
    // El effect se ejecuta cada vez que dialogVisible cambia.
    // Cuando el dialog cierra (false), refrescamos la lista para mostrar los cambios guardados
    effect(() => {
      if (!this.dialogVisible()) {
        this.refrescarProyectos();
      }
    });
  }

  ngOnInit(): void {
    this.refrescarProyectos();
  }

  refrescarProyectos(): void {
    const filtro: { nombre?: string; estado?: string } = {};
    if (this.filtroNombre.trim()) filtro.nombre = this.filtroNombre.trim();
    if (this.filtroEstado) filtro.estado = this.filtroEstado;

    this.proyectosListadoApiClient.buscarProyectos(filtro).subscribe({
      next: (data) => this.proyectos.set(data),
      error: () => this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron obtener los proyectos' })
    });
  }

  buscar(): void {
    this.refrescarProyectos();
  }

  limpiarFiltros(): void {
    this.filtroNombre = '';
    this.filtroEstado = '';
    this.refrescarProyectos();
  }

  crearProyecto(): void {
    this.proyectoSeleccionado.set(null);
    this.dialogVisible.set(true);
  }

  editarProyecto(proyecto: ListProyectoDTO): void {
    this.proyectoSeleccionado.set(proyecto);
    this.dialogVisible.set(true);
  }

  // Navega a la pantalla de tareas del proyecto seleccionado
  verTareas(proyecto: ListProyectoDTO): void {
    this.router.navigateByUrl(`/proyectos/${proyecto.id}/tareas`);
  }

  // Expansión: Exportación de datos — genera y descarga un archivo CSV
  // con los proyectos actualmente visibles en la tabla (respeta los filtros aplicados)
  exportarCSV(): void {
    const proyectos = this.proyectos();
    if (!proyectos.length) {
      this.messageService.add({ severity: 'warn', summary: 'Sin datos', detail: 'No hay proyectos para exportar' });
      return;
    }

    const encabezado = ['ID', 'Nombre', 'Cliente', 'Estado'];
    const filas = proyectos.map(p => [
      p.id,
      `"${p.nombre.replace(/"/g, '""')}"`,
      p.cliente ? `"${p.cliente.nombre.replace(/"/g, '""')}"` : '—',
      p.estado,
    ]);

    const contenido = [encabezado, ...filas].map(f => f.join(',')).join('\n');
    const blob = new Blob(['﻿' + contenido], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `impulso-pm-proyectos-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    this.messageService.add({ severity: 'success', summary: 'CSV exportado', detail: `${proyectos.length} proyectos descargados` });
  }

}
