import { EstadosProyectosEnum } from "../estados-proyectos-enum";

export interface UpdateProyectoDto {
  nombre: string;
  idCliente: number | null;
  estado: EstadosProyectosEnum;
}
