import { Component, computed, effect, inject, model, ModelSignal, OnInit, Signal, signal, WritableSignal } from "@angular/core";
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { MessageService } from "primeng/api";
import { DialogModule } from "primeng/dialog";
import { InputTextModule } from "primeng/inputtext";
import { SelectModule } from "primeng/select";
import { ButtonModule } from "primeng/button";
import { NgSelectModule } from "@ng-select/ng-select";
import { GestionProyectoApiClient } from "./gestion-proyecto-api-client";
import { ClientesListadoApiClient } from "../clientes/listado/clientes-listado-api-client";
import { ClientesListado } from "../clientes/listado/clientes-listado";
import { ListProyectoDTO } from "../listado/list-proyecto-dto";
import { ListClienteDTO } from "../clientes/listado/list-cliente-dto";
import { CreateProyectoDTO } from "./create-proyecto-dto";
import { UpdateProyectoDto } from "./update-proyecto-dto";
import { EstadosProyectosEnum } from "../estados-proyectos-enum";
import { EstadosClientesEnum } from "../clientes/estados-clientes-enum";

@Component({
  selector: "app-gestion-proyecto",
  templateUrl: "./gestion-proyecto.html",
  styleUrls: ["./gestion-proyecto.css"],
  imports: [DialogModule, InputTextModule, SelectModule, ButtonModule, ReactiveFormsModule, NgSelectModule, ClientesListado]
})
export class GestionProyecto implements OnInit {

  visible: ModelSignal<boolean> = model(false);
  proyectoSeleccionado: ModelSignal<ListProyectoDTO | null> = model<ListProyectoDTO | null>(null);

  readonly dialogClientesVisible: WritableSignal<boolean> = signal(false);
  readonly estados: WritableSignal<string[]> = signal(Object.values(EstadosProyectosEnum));
  readonly clientes: WritableSignal<ListClienteDTO[]> = signal([]);

  private readonly messageService: MessageService = inject(MessageService);
  private readonly gestionProyectoApiClient = inject(GestionProyectoApiClient);
  private readonly clientesListadoApiClient: ClientesListadoApiClient = inject(ClientesListadoApiClient);

  header: Signal<string> = computed(() =>
    this.proyectoSeleccionado() ? "Editar proyecto" : "Crear proyecto"
  );

  readonly form: FormGroup = new FormGroup({
    nombre: new FormControl("", [Validators.required]),
    cliente: new FormControl(null),
    estado: new FormControl(null)
  });

  constructor() {
    // Este effect precarga el formulario con los datos del proyecto cuando editamos,
    // o lo resetea cuando abrimos el dialog para crear uno nuevo
    effect(() => {
      const p = this.proyectoSeleccionado();
      if (p) {
        this.form.patchValue({ nombre: p.nombre, cliente: p.cliente, estado: p.estado });
      } else {
        this.form.reset({ nombre: "", cliente: null, estado: EstadosProyectosEnum.ACTIVO });
      }
    });

    // Cuando se cierra el sub-dialog de clientes, recargamos la lista
    // para mostrar cualquier cliente que se haya creado ahí mismo
    effect(() => {
      if (!this.dialogClientesVisible()) {
        this.refrescarClientes();
      }
    });
  }

  ngOnInit(): void {
    this.refrescarClientes();
  }

  refrescarClientes(): void {
    this.clientesListadoApiClient.buscarClientes(EstadosClientesEnum.ACTIVO).subscribe({
      next: (data) => this.clientes.set(data),
      error: () => this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron obtener los clientes' })
    });
  }

  cerrarDialog(): void {
    this.proyectoSeleccionado.set(null);
    this.visible.set(false);
  }

  gestionarClientes(): void {
    this.dialogClientesVisible.set(true);
  }

  guardarProyecto(): void {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Complete todos los campos requeridos' });
      return;
    }

    const formRawValue = this.form.getRawValue();

    if (this.proyectoSeleccionado()) {
      const dto: UpdateProyectoDto = {
        nombre: formRawValue.nombre,
        idCliente: formRawValue.cliente ? formRawValue.cliente.id : null,
        estado: formRawValue.estado
      };
      this.gestionProyectoApiClient.actualizarProyecto(this.proyectoSeleccionado()!.id, dto).subscribe({
        next: () => {
          this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Proyecto actualizado correctamente' });
          this.cerrarDialog();
        },
        error: (err) => {
          const detail = err.error?.statusCode >= 400 && err.error?.statusCode < 500
            ? err.error.message
            : "Error al actualizar el proyecto";
          this.messageService.add({ severity: 'error', summary: 'Error', detail });
        }
      });
    } else {
      const dto: CreateProyectoDTO = {
        nombre: formRawValue.nombre,
        idCliente: formRawValue.cliente ? formRawValue.cliente.id : null
      };
      this.gestionProyectoApiClient.crearProyecto(dto).subscribe({
        next: () => {
          this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Proyecto creado correctamente' });
          this.cerrarDialog();
        },
        error: (err) => {
          const detail = err.error?.statusCode >= 400 && err.error?.statusCode < 500
            ? err.error.message
            : "Error al crear el proyecto";
          this.messageService.add({ severity: 'error', summary: 'Error', detail });
        }
      });
    }
  }

}
