# Impulso PM — Sistema de gestión de proyectos

Sistema de gestión de proyectos para una agencia de marketing, desarrollado como Trabajo Práctico Integrador de Desarrollo de Aplicaciones Web (DAW) 2026.

Permite gestionar clientes, proyectos y tareas con autenticación JWT, búsqueda avanzada con filtros y paginación, y exportación de datos a CSV.

---

## Tecnologías utilizadas

| Capa | Tecnología | Versión |
|------|-----------|---------|
| Backend | NestJS | 11 |
| ORM | TypeORM | 1.0 |
| Base de datos | PostgreSQL | 16 |
| Autenticación | @nestjs/jwt + bcrypt | — |
| Validaciones | class-validator + class-transformer | — |
| Documentación API | @nestjs/swagger | 11 |
| Seguridad HTTP | helmet | 8 |
| Frontend | Angular (standalone + Signals) | 21 |
| UI Components | PrimeNG (preset Aura, tema oscuro) | 21 |
| Selector con búsqueda | @ng-select/ng-select | — |
| Tipografías | Space Grotesk + Inter (Google Fonts) | — |
| Proceso Node.js | PM2 | — |
| Servidor web | nginx | 1.30.2 |

---

## Estructura del proyecto

```
TP-integrador/
  backend/          ← API REST en NestJS
    src/
      auth/         ← login con JWT
      usuarios/     ← CRUD de usuarios
      clientes/     ← CRUD de clientes con búsqueda avanzada
      proyectos/    ← CRUD de proyectos con búsqueda avanzada
      tareas/       ← CRUD de tareas anidadas bajo proyectos
      seed/         ← datos iniciales de ejemplo (agencia de marketing)
    ecosystem.config.js   ← configuración PM2
    .env                  ← variables de entorno (no subir al repo)
  frontend/
    src/app/
      auth/         ← login, interceptor JWT, auth-store
      template/     ← layout con sidebar (Impulso PM)
      proyectos/    ← listado, gestión, clientes, tareas
  docs/             ← documentación de la cátedra (solo lectura)
```

---

## Cómo levantar en desarrollo

### Requisitos previos

- Node.js 20+
- PostgreSQL corriendo en `localhost:5432`
- La base de datos se crea automáticamente al iniciar el backend (no hace falta crearla a mano)

### 1. Configurar el backend

Crear el archivo `backend/.env` con estas variables:

```
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=tu_clave_de_postgres
DB_NAME=impulso_bd
DB_LOGGING=true
SWAGGER_HABILITADO=true
JWT_SECRET=una_clave_secreta_larga_y_segura
```

Iniciar el servidor:

```bash
cd backend
npm run start:dev
```

La API queda disponible en `http://localhost:3000`.
La documentación Swagger en `http://localhost:3000/api`.

> **Nota:** al iniciar por primera vez, TypeORM crea las tablas automáticamente (`synchronize: true`) y el seed carga los datos de ejemplo. No se usan migraciones.

### 2. Iniciar el frontend

```bash
cd frontend
npm start
```

El frontend queda disponible en `http://localhost:4200`, con proxy al backend configurado automáticamente (ver `proxy.conf.json`).

### Credenciales de prueba

| Usuario | Contraseña |
|---------|-----------|
| admin | admin123 |
| operador | operador123 |

### Datos de ejemplo incluidos

**Clientes:** Grupo Clarín Digital, Mercado Libre Argentina, Quilmes Experiencias, Telecom Argentina (baja)

**Proyectos:** Campaña digital verano 2027, Rebranding e-commerce, Activación marca Quilmes Rock, Optimización procesos internos, Campaña Navidad Clarín 2025 (finalizado)

---

## Funcionalidades del sistema

### CRUD completo
- **Usuarios:** alta, modificación, baja lógica (estado Activo/Baja)
- **Clientes:** alta, modificación, baja lógica con validación (no se puede dar de baja si tiene proyectos asignados)
- **Proyectos:** alta, modificación, baja lógica, asignación de cliente opcional
- **Tareas:** alta, modificación, baja lógica, anidadas bajo un proyecto

### Reglas de negocio
- Las contraseñas se almacenan hasheadas con bcrypt
- La baja siempre es lógica (cambia el campo `estado`, nunca borra el registro)
- No se puede asignar un cliente en estado "Baja" a un proyecto
- No se puede dar de baja un cliente que tiene proyectos asignados

### Autenticación
- Login con usuario y contraseña → devuelve JWT (8 horas de vigencia)
- Todas las rutas del backend (excepto el login) requieren el token en el header `Authorization: Bearer <token>`
- El frontend guarda el token en `sessionStorage` y lo adjunta automáticamente a cada request via interceptor Angular

---

## Funcionalidades adicionales implementadas

### 1. Búsqueda avanzada (filtrado + paginación)

Disponible en las vistas de **Proyectos** y **Clientes**.

**Backend:** endpoint `GET /proyectos` acepta query params opcionales:
```
?nombre=campaña&estado=ACTIVO&page=1&limit=10&orderBy=nombre&order=ASC
```
Implementado con `QueryBuilder` de TypeORM. Si no se envían parámetros, devuelve todos los registros. La respuesta paginada tiene la forma:
```json
{ "data": [...], "total": 5, "page": 1, "limit": 10 }
```

**Frontend:** campo de texto para filtrar por nombre + selector de estado + botones "Buscar" y "Limpiar filtros", con paginador integrado en la tabla PrimeNG.

### 2. Exportación de datos a CSV

Disponible en la vista de **Proyectos** mediante el botón **"Exportar CSV"**.

- Exporta los proyectos actualmente visibles en la tabla (respeta los filtros aplicados)
- Columnas: ID, Nombre, Cliente, Estado
- Formato CSV con BOM UTF-8 para compatibilidad con Microsoft Excel (tildes y ñ correctos)
- El archivo se descarga con el nombre `impulso-pm-proyectos-YYYY-MM-DD.csv`
- Implementado íntegramente en el frontend con APIs nativas del browser (sin paquetes adicionales)

---

## Build y despliegue local

### Backend con PM2

```bash
cd backend
npm run build
pm2 start ecosystem.config.js
pm2 save
```

Comandos útiles de PM2:
```bash
pm2 list                  # ver procesos
pm2 logs impulso-backend  # ver logs en tiempo real
pm2 restart impulso-backend
```

### Frontend compilado

```bash
cd frontend
npx ng build --configuration production
```

Los archivos compilados quedan en `frontend/dist/frontend/browser/`.

### nginx

El archivo de configuración está en `C:\nginx-1.30.2\conf\nginx.conf`.

Configuración clave:
- Puerto 443 (HTTPS con certificado local)
- Sirve los archivos estáticos del frontend compilado
- Proxy inverso: `/api/` → `http://localhost:3000/api/`
- SPA fallback: cualquier ruta desconocida redirige a `index.html`

```bash
# Desde C:\nginx-1.30.2\
nginx.exe          # iniciar
nginx.exe -s reload   # recargar config
nginx.exe -s stop     # detener
```

La app queda disponible en `https://localhost`.

Chicos en el .env y en ecosystem.config.js tienen que colocar la contraseña que le pusieron a pgAdmin